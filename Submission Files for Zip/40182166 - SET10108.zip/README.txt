
Valentina Scarfi - 400182166

Concurrent and Parallel Systems (SET10108)
-------------------------------------------------------------------------------
This folder contains:

	* A pdf report
	* An excel file containing all results and graphs used for the report
	  (different sheets in one file has been used)
	* A folder containing some output images
	* A folder containing:
			# four different .cpp files - one for each implementation
	  		  plus the one containing the original algorithm
			# a folder with Visual Studio Performance Profiler files
		